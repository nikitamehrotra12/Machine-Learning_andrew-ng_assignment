function [theta, J_history] = gradientDescentMulti(X, y, theta, alpha, num_iters)
%GRADIENTDESCENTMULTI Performs gradient descent to learn theta
%   theta = GRADIENTDESCENTMULTI(x, y, theta, alpha, num_iters) updates theta by
%   taking num_iters gradient steps with learning rate alpha

% Initialize some useful values
m = length(y); % number of training examples
J_history = zeros(num_iters, 1);
% J_all = zeros(num_iters,5);
% for a = 1:alpha
for iter = 1:num_iters

% ====================== YOUR CODE HERE ======================
% Instructions: Perform a single gradient step on the parameter vector
%               theta. 
%
% Hint: While debugging, it can be useful to print out the values
%       of the cost function (computeCostMulti) and gradient here.
%
P = X*theta - y;
theta = theta - ((transpose(X) * P)*alpha)/m;
% ============================================================

% Save the cost J in every iteration    
J_history(iter) = computeCostMulti(X, y, theta);
end
% alpha1 = [0.1,0.01,0.5];
% iters = 50;
% J_1 = zeros(iters,3);
% for a = 1:3
%     for i = 1:iters
%         P = X*theta - y;
%         theta = theta - ((transpose(X) * P)*alpha1(a))/m;
%         J_1(i,a) =  computeCostMulti(X, y, theta);
%     end
% end
% figure;
% plot(1:50,J_1(:,1),'b');
% hold on;
% plot(1:50,J_1(:,2),'r');
% hold on;
% plot(1:50,J_1(:,3),'g');

